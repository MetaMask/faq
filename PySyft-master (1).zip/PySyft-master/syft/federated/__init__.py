from syft.federated.plan import Plan

from syft.federated.plan import func2plan
from syft.federated.plan import method2plan
from syft.federated.plan import make_plan

__all__ = ["plan", "func2plan", "method2plan", "make_plan"]
